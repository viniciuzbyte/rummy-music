/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.rummy

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object RummyWelcomeState {
    private const val FILE = "rummy_ui"
    private const val KEY = "welcome_seen"

    fun seen(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY, false)

    fun markSeen(context: Context) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY, true).apply()
    }
}

@Composable
fun RummyWelcomeOverlay(
    modifier: Modifier = Modifier,
    onlyFirstLaunch: Boolean = false,
) {
    val context = LocalContext.current
    var show by rememberSaveable {
        mutableStateOf(!onlyFirstLaunch || !RummyWelcomeState.seen(context))
    }
    if (show) {
        RummyWelcome(
            modifier = modifier,
            onFinished = {
                RummyWelcomeState.markSeen(context)
                show = false
            },
        )
    }
}

@Composable
fun RummyWelcome(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val ease = remember { CubicBezierEasing(0.22f, 1f, 0.36f, 1f) }

    val logoScale = remember { Animatable(0.55f) }
    val logoAlpha = remember { Animatable(0f) }
    val greet = remember { Animatable(0f) }
    val name = remember { Animatable(0f) }
    val tagline = remember { Animatable(0f) }
    val exit = remember { Animatable(0f) }
    var finishing by remember { mutableStateOf(false) }

    val transition = rememberInfiniteTransition(label = "rummyWelcome")
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
        label = "sweep",
    )
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { logoAlpha.animateTo(1f, tween(450)) }
            launch { logoScale.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessLow)) }
            launch { delay(260); greet.animateTo(1f, tween(600, easing = ease)) }
            launch { delay(420); name.animateTo(1f, tween(700, easing = ease)) }
            launch { delay(620); tagline.animateTo(1f, tween(700, easing = ease)) }
        }
        delay(900)
        if (!finishing) {
            finishing = true
            exit.animateTo(1f, tween(480, easing = ease))
            onFinished()
        }
    }

    val backdrop = Brush.verticalGradient(
        listOf(
            scheme.background,
            lerp(scheme.background, scheme.primary, 0.16f),
            scheme.background,
        ),
    )
    val titleBrush = Brush.linearGradient(listOf(scheme.primary, scheme.tertiary))

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = 1f - exit.value
                val s = 1f + 0.06f * exit.value
                scaleX = s
                scaleY = s
            }
            .background(backdrop)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) {
                if (!finishing) {
                    finishing = true
                    scope.launch {
                        exit.animateTo(1f, tween(360, easing = ease))
                        onFinished()
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(156.dp)
                    .graphicsLayer {
                        val s = logoScale.value * (1f + 0.03f * pulse)
                        scaleX = s
                        scaleY = s
                        alpha = logoAlpha.value
                    },
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = center
                    val minDim = size.minDimension
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(scheme.primary.copy(alpha = 0.26f + 0.12f * pulse), Color.Transparent),
                            center = c,
                            radius = minDim * 0.66f,
                        ),
                        radius = minDim * 0.66f,
                        center = c,
                    )
                    rotate(degrees = sweep, pivot = c) {
                        drawCircle(
                            brush = Brush.sweepGradient(
                                colors = listOf(
                                    scheme.primary,
                                    scheme.tertiary,
                                    scheme.primary.copy(alpha = 0f),
                                    scheme.primary,
                                ),
                                center = c,
                            ),
                            radius = minDim * 0.46f,
                            center = c,
                            style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round),
                        )
                    }
                    val discRadius = minDim * 0.36f
                    drawCircle(
                        brush = Brush.linearGradient(
                            colors = listOf(scheme.primary, scheme.tertiary),
                            start = Offset(c.x - discRadius, c.y - discRadius),
                            end = Offset(c.x + discRadius, c.y + discRadius),
                        ),
                        radius = discRadius,
                        center = c,
                    )
                    val triangle = Path().apply {
                        moveTo(c.x - discRadius * 0.22f, c.y - discRadius * 0.42f)
                        lineTo(c.x - discRadius * 0.22f, c.y + discRadius * 0.42f)
                        lineTo(c.x + discRadius * 0.46f, c.y)
                        close()
                    }
                    drawPath(triangle, scheme.onPrimary)
                    drawPath(
                        triangle,
                        scheme.onPrimary,
                        style = Stroke(width = 6.dp.toPx(), join = StrokeJoin.Round),
                    )
                }
            }

            Spacer(Modifier.height(36.dp))

            Text(
                text = "Welcome to",
                modifier = Modifier.graphicsLayer {
                    alpha = greet.value
                    translationY = (1f - greet.value) * 24.dp.toPx()
                },
                style = TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 4.sp,
                    color = scheme.onSurface.copy(alpha = 0.7f),
                ),
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = "Rummy Music",
                modifier = Modifier.graphicsLayer {
                    alpha = name.value
                    translationY = (1f - name.value) * 32.dp.toPx()
                    val s = 0.92f + 0.08f * name.value
                    scaleX = s
                    scaleY = s
                },
                style = TextStyle(
                    brush = titleBrush,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-0.5).sp,
                ),
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text = "Your music. Your rhythm.",
                modifier = Modifier.graphicsLayer {
                    alpha = tagline.value
                    translationY = (1f - tagline.value) * 16.dp.toPx()
                },
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = 0.6.sp,
                    color = scheme.onSurface.copy(alpha = 0.6f),
                ),
            )
        }
    }
}

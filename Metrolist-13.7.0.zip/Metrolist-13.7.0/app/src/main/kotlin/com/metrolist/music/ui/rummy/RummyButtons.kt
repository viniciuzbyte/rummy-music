/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.rummy

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private val PlayLeft = floatArrayOf(0.08f, 0f, 0.52f, 0.26f, 0.52f, 0.74f, 0.08f, 1f)
private val PlayRight = floatArrayOf(0.52f, 0.26f, 1f, 0.5f, 1f, 0.5f, 0.52f, 0.74f)
private val PauseLeft = floatArrayOf(0f, 0f, 0.34f, 0f, 0.34f, 1f, 0f, 1f)
private val PauseRight = floatArrayOf(0.66f, 0f, 1f, 0f, 1f, 1f, 0.66f, 1f)

private fun morphPath(
    from: FloatArray,
    to: FloatArray,
    t: Float,
    w: Float,
    h: Float,
    dx: Float,
): Path {
    fun x(i: Int) = (from[i * 2] + (to[i * 2] - from[i * 2]) * t) * w + dx

    fun y(i: Int) = (from[i * 2 + 1] + (to[i * 2 + 1] - from[i * 2 + 1]) * t) * h
    return Path().apply {
        moveTo(x(0), y(0))
        lineTo(x(1), y(1))
        lineTo(x(2), y(2))
        lineTo(x(3), y(3))
        close()
    }
}

@Composable
fun PlayPauseMorph(
    progress: () -> Float,
    tint: Color,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier) {
        val t = progress()
        val w = size.width
        val h = size.height
        val dx = (1f - t) * 0.05f * w
        val stroke = Stroke(width = 0.12f * w, join = StrokeJoin.Round)
        val left = morphPath(PlayLeft, PauseLeft, t, w, h, dx)
        val right = morphPath(PlayRight, PauseRight, t, w, h, dx)
        drawPath(left, tint)
        drawPath(left, tint, style = stroke)
        drawPath(right, tint)
        drawPath(right, tint, style = stroke)
    }
}

@Composable
fun RummyPlayPauseGlyph(
    isPlaying: Boolean,
    tint: Color,
    modifier: Modifier = Modifier,
) {
    val morph by animateFloatAsState(
        targetValue = if (isPlaying) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
        label = "playPauseGlyph",
    )
    PlayPauseMorph(
        progress = { morph },
        tint = tint,
        modifier = modifier,
    )
}

@Composable
private fun PlayRing(modifier: Modifier = Modifier, color: Color) {
    val transition = rememberInfiniteTransition(label = "playRing")
    val ring by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "ring",
    )
    Box(
        modifier = modifier.drawBehind {
            val r = size.minDimension / 2f
            drawCircle(
                color = color.copy(alpha = 0.35f * (1f - ring)),
                radius = r * (1f + 0.45f * ring),
                center = center,
                style = Stroke(width = 2.dp.toPx()),
            )
        },
    )
}

@Composable
fun RummyPlayButton(
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 72.dp,
    enabled: Boolean = true,
) {
    val scheme = MaterialTheme.colorScheme
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()

    val pressScale by animateFloatAsState(
        targetValue = if (pressed) 0.9f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 600f),
        label = "playPress",
    )
    val morph by animateFloatAsState(
        targetValue = if (isPlaying) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
        label = "playMorph",
    )
    val glow by animateFloatAsState(
        targetValue = if (isPlaying) 1f else 0.55f,
        animationSpec = tween(450),
        label = "playGlow",
    )

    val fill = Brush.linearGradient(listOf(scheme.primary, lerp(scheme.primary, scheme.tertiary, 0.55f)))

    Box(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
            }
            .drawBehind {
                val r = this.size.minDimension / 2f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(scheme.primary.copy(alpha = 0.32f * glow), Color.Transparent),
                        center = center,
                        radius = r * 1.7f,
                    ),
                    radius = r * 1.7f,
                    center = center,
                )
            }
            .shadow(
                elevation = 10.dp,
                shape = CircleShape,
                ambientColor = scheme.primary,
                spotColor = scheme.primary,
            )
            .clip(CircleShape)
            .background(fill)
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.38f), Color.White.copy(alpha = 0.04f)),
                ),
                shape = CircleShape,
            )
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                role = Role.Button,
            ) {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        if (isPlaying) {
            PlayRing(Modifier.size(size), scheme.primary)
        }
        PlayPauseMorph(
            progress = { morph },
            tint = scheme.onPrimary,
            modifier = Modifier.size(size * 0.38f),
        )
    }
}

@Composable
fun RummyPlayBadge(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
) {
    val scheme = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .size(size)
            .shadow(
                elevation = 6.dp,
                shape = CircleShape,
                ambientColor = scheme.primary,
                spotColor = scheme.primary,
            )
            .clip(CircleShape)
            .background(
                Brush.linearGradient(listOf(scheme.primary, lerp(scheme.primary, scheme.tertiary, 0.55f))),
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.38f), Color.White.copy(alpha = 0.04f)),
                ),
                shape = CircleShape,
            ),
        contentAlignment = Alignment.Center,
    ) {
        PlayPauseMorph(
            progress = { 0f },
            tint = scheme.onPrimary,
            modifier = Modifier.size(size * 0.38f),
        )
    }
}

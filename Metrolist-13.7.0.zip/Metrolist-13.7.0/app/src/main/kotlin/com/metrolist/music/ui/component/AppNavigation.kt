/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.metrolist.music.ui.screens.Screens
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@Stable
private fun isRouteSelected(currentRoute: String?, screenRoute: String, navigationItems: List<Screens>): Boolean {
    if (currentRoute == null) return false
    if (currentRoute == screenRoute) return true
    if (navigationItems.any { it.route == screenRoute } &&
        currentRoute.startsWith("$screenRoute/")) return true

    // Fix: match the route template, not the resolved route
    if (screenRoute == "search_input" &&
        (currentRoute.startsWith("search/") || currentRoute == "search/{query}")) return true

    return false
}

@Composable
fun AppNavigationRail(
    navigationItems: List<Screens>,
    currentRoute: String?,
    onItemClick: (Screens, Boolean) -> Unit,
    modifier: Modifier = Modifier,
    pureBlack: Boolean = false,
    onSearchLongClick: (() -> Unit)? = null,
    onHomeLongHold: (() -> Unit)? = null,
) {
    val containerColor = if (pureBlack) Color.Black else MaterialTheme.colorScheme.surfaceContainer
    val haptics = LocalHapticFeedback.current
    val viewConfiguration = LocalViewConfiguration.current

    NavigationRail(
        modifier = modifier,
        containerColor = containerColor
    ) {
        Spacer(modifier = Modifier.weight(1f))

        navigationItems.forEach { screen ->
            val isSelected = remember(currentRoute, screen.route) {
                isRouteSelected(currentRoute, screen.route, navigationItems)
            }
            val currentIsSelected by rememberUpdatedState(isSelected)
            val iconRes = remember(isSelected, screen) {
                if (isSelected) screen.iconIdActive else screen.iconIdInactive
            }

            val isSearchItem = screen == Screens.Search && onSearchLongClick != null
            val isHomeHoldItem = screen == Screens.Home && onHomeLongHold != null
            val interactionSource = remember { MutableInteractionSource() }

            // Long press detection using InteractionSource
            if (isSearchItem || isHomeHoldItem) {
                LaunchedEffect(interactionSource) {
                    var isLongClick = false
                    interactionSource.interactions.collectLatest { interaction ->
                        when (interaction) {
                            is PressInteraction.Press -> {
                                isLongClick = false
                                delay(if (isHomeHoldItem) 15_000L else viewConfiguration.longPressTimeoutMillis)
                                isLongClick = true
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                if (isHomeHoldItem) onHomeLongHold.invoke() else onSearchLongClick?.invoke()
                            }
                            is PressInteraction.Release -> {
                                if (!isLongClick) {
                                    onItemClick(screen, currentIsSelected)
                                }
                            }
                            is PressInteraction.Cancel -> {
                                isLongClick = false
                            }
                        }
                    }
                }
            }

            NavigationRailItem(
                selected = isSelected,
                onClick = {
                    if (!isSearchItem && !isHomeHoldItem) {
                        onItemClick(screen, currentIsSelected)
                    }
                    // Long presses are handled via InteractionSource
                },
                interactionSource = interactionSource,
                icon = {
                    Icon(
                        painter = painterResource(id = iconRes),
                        contentDescription = stringResource(screen.titleId)
                    )
                }
            )
        }

        Spacer(modifier = Modifier.weight(1f))
    }
}

@Composable
fun AppNavigationBar(
    navigationItems: List<Screens>,
    currentRoute: String?,
    onItemClick: (Screens, Boolean) -> Unit,
    modifier: Modifier = Modifier,
    pureBlack: Boolean = false,
    slimNav: Boolean = false,
    onSearchLongClick: (() -> Unit)? = null,
    onHomeLongHold: (() -> Unit)? = null,
) {
    if (navigationItems.isEmpty()) return

    val scheme = MaterialTheme.colorScheme
    val containerColor = if (pureBlack) Color.Black else scheme.surfaceContainer
    val pillColor = if (pureBlack) Color(0xFF151515) else scheme.surfaceContainerHigh
    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val count = navigationItems.size
    val barHeight = if (slimNav) 48.dp else 64.dp
    val inset = 6.dp
    val barShape = RoundedCornerShape(if (slimNav) 26.dp else 32.dp)
    val highlightShape = RoundedCornerShape(if (slimNav) 22.dp else 28.dp)

    val latestItems by rememberUpdatedState(navigationItems)
    val latestRoute by rememberUpdatedState(currentRoute)
    val latestOnItemClick by rememberUpdatedState(onItemClick)
    val latestSearchLongClick by rememberUpdatedState(onSearchLongClick)
    val latestHomeLongHold by rememberUpdatedState(onHomeLongHold)

    val selectedIndex =
        remember(currentRoute, navigationItems) {
            navigationItems.indexOfFirst { isRouteSelected(currentRoute, it.route, navigationItems) }
        }
    val latestSelectedIndex by rememberUpdatedState(selectedIndex)

    var previewIndex by remember { mutableIntStateOf(selectedIndex) }
    var pressed by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    val position = remember { Animatable(selectedIndex.coerceAtLeast(0).toFloat()) }

    LaunchedEffect(selectedIndex) {
        if (!pressed) previewIndex = selectedIndex
    }
    LaunchedEffect(previewIndex, dragging) {
        if (!dragging && previewIndex >= 0) {
            position.animateTo(
                previewIndex.toFloat(),
                spring(dampingRatio = 0.72f, stiffness = 380f),
            )
        }
    }

    val pressScale by animateFloatAsState(
        targetValue = if (pressed) 1.1f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "navHighlightPress",
    )
    val highlightAlpha by animateFloatAsState(
        targetValue = if (previewIndex >= 0 || pressed) 1f else 0f,
        animationSpec = tween(180),
        label = "navHighlightAlpha",
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(containerColor),
        contentAlignment = Alignment.TopCenter,
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .padding(start = 20.dp, end = 20.dp, top = 8.dp)
                .fillMaxWidth()
                .height(barHeight)
                .shadow(
                    elevation = 12.dp,
                    shape = barShape,
                    ambientColor = scheme.primary.copy(alpha = 0.2f),
                    spotColor = scheme.primary.copy(alpha = 0.25f),
                )
                .clip(barShape)
                .background(pillColor)
                .border(
                    width = 1.dp,
                    brush = Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.14f),
                            Color.White.copy(alpha = 0.03f),
                        ),
                    ),
                    shape = barShape,
                )
                .pointerInput(count) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val insetPx = inset.toPx()
                        val itemW = (size.width - 2 * insetPx) / count

                        fun indexAt(x: Float): Int = ((x - insetPx) / itemW).toInt().coerceIn(0, count - 1)

                        pressed = true
                        var target = indexAt(down.position.x)
                        if (target != previewIndex) {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        }
                        previewIndex = target

                        var fired = false
                        val pressedScreen = latestItems.getOrNull(target)
                        val homeHold = if (pressedScreen == Screens.Home) latestHomeLongHold else null
                        val searchHold = if (pressedScreen == Screens.Search) latestSearchLongClick else null
                        val holdAction = homeHold ?: searchHold
                        val holdDelay = if (homeHold != null) 15_000L else viewConfiguration.longPressTimeoutMillis
                        val holdJob: Job? =
                            if (holdAction != null) {
                                scope.launch {
                                    delay(holdDelay)
                                    fired = true
                                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                    holdAction()
                                }
                            } else {
                                null
                            }

                        var moved = false
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) break
                            val x = change.position.x
                            if (!moved && abs(x - down.position.x) > viewConfiguration.touchSlop) {
                                moved = true
                                dragging = true
                                holdJob?.cancel()
                            }
                            if (moved) {
                                val f = ((x - insetPx) / itemW - 0.5f).coerceIn(0f, (count - 1).toFloat())
                                scope.launch { position.snapTo(f) }
                                val idx = indexAt(x)
                                if (idx != target) {
                                    target = idx
                                    previewIndex = idx
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                                change.consume()
                            }
                        }

                        holdJob?.cancel()
                        dragging = false
                        pressed = false
                        if (fired) {
                            previewIndex = latestSelectedIndex
                        } else {
                            previewIndex = target
                            val screen = latestItems.getOrNull(target)
                            if (screen != null) {
                                latestOnItemClick(
                                    screen,
                                    isRouteSelected(latestRoute, screen.route, latestItems),
                                )
                            }
                        }
                    }
                },
        ) {
            val itemWidth = (maxWidth - inset * 2) / count
            val itemHeight = barHeight - inset * 2

            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            x = (inset.toPx() + position.value * itemWidth.toPx()).roundToInt(),
                            y = inset.roundToPx(),
                        )
                    }
                    .width(itemWidth)
                    .height(itemHeight)
                    .graphicsLayer {
                        alpha = highlightAlpha
                        scaleX = pressScale
                        scaleY = 1f + (pressScale - 1f) * 0.6f
                    }
                    .clip(highlightShape)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                scheme.primary.copy(alpha = 0.28f),
                                scheme.primary.copy(alpha = 0.15f),
                            ),
                        ),
                    )
                    .border(
                        width = 1.dp,
                        color = scheme.primary.copy(alpha = 0.32f),
                        shape = highlightShape,
                    ),
            )

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(inset),
            ) {
                navigationItems.forEachIndexed { index, screen ->
                    AppNavigationBarItem(
                        screen = screen,
                        showLabel = !slimNav,
                        selected = index == selectedIndex,
                        fraction = { (1f - abs(position.value - index)).coerceIn(0f, 1f) * highlightAlpha },
                        inactiveColor = if (pureBlack) Color.White.copy(alpha = 0.72f) else scheme.onSurfaceVariant,
                        onActivate = {
                            latestOnItemClick(screen, isRouteSelected(latestRoute, screen.route, latestItems))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize(),
                    )
                }
            }
        }
    }
}

@Composable
private fun AppNavigationBarItem(
    screen: Screens,
    showLabel: Boolean,
    selected: Boolean,
    fraction: () -> Float,
    inactiveColor: Color,
    onActivate: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val title = stringResource(screen.titleId)

    Column(
        modifier = modifier.semantics(mergeDescendants = true) {
            role = Role.Tab
            this.selected = selected
            contentDescription = title
            onClick(label = title) {
                onActivate()
                true
            }
        },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .graphicsLayer {
                    val s = 1f + 0.1f * fraction()
                    scaleX = s
                    scaleY = s
                    translationY = -1.5.dp.toPx() * fraction()
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(id = screen.iconIdInactive),
                contentDescription = null,
                tint = inactiveColor,
                modifier = Modifier
                    .size(24.dp)
                    .graphicsLayer { alpha = 1f - fraction() },
            )
            Icon(
                painter = painterResource(id = screen.iconIdActive),
                contentDescription = null,
                tint = scheme.primary,
                modifier = Modifier
                    .size(24.dp)
                    .graphicsLayer { alpha = fraction() },
            )
        }

        if (showLabel) {
            Box(
                modifier = Modifier.padding(top = 3.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = inactiveColor,
                    modifier = Modifier.graphicsLayer { alpha = 1f - fraction() },
                )
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = scheme.primary,
                    modifier = Modifier.graphicsLayer { alpha = fraction() },
                )
            }
        }
    }
}

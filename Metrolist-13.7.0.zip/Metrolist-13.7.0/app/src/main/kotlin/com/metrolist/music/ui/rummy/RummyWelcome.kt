/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.rummy

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun RummyLoadingGate(
    isReady: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    var overlayVisible by remember { mutableStateOf(true) }
    val exitProgress = remember { Animatable(0f) }

    LaunchedEffect(isReady) {
        if (isReady) {
            exitProgress.animateTo(
                1f,
                tween(420, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)),
            )
            overlayVisible = false
        }
    }

    Box(modifier.fillMaxSize()) {
        content()

        if (overlayVisible) {
            RummyLoadingScreen(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        alpha = 1f - exitProgress.value
                        val s = 1f + 0.05f * exitProgress.value
                        scaleX = s
                        scaleY = s
                    },
            )
        }
    }
}

@Composable
private fun RummyLoadingScreen(modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val ease = remember { CubicBezierEasing(0.22f, 1f, 0.36f, 1f) }

    val logoScale = remember { Animatable(0.55f) }
    val logoAlpha = remember { Animatable(0f) }
    val nameAlpha = remember { Animatable(0f) }
    val tagAlpha = remember { Animatable(0f) }

    val transition = rememberInfiniteTransition(label = "rummyLoading")
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
        label = "sweep",
    )
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { logoAlpha.animateTo(1f, tween(400)) }
            launch { logoScale.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessLow)) }
            launch { delay(220); nameAlpha.animateTo(1f, tween(550, easing = ease)) }
            launch { delay(380); tagAlpha.animateTo(1f, tween(550, easing = ease)) }
        }
    }

    val backdrop = Brush.verticalGradient(
        listOf(
            scheme.background,
            androidx.compose.ui.graphics.lerp(scheme.background, scheme.primary, 0.14f),
            scheme.background,
        ),
    )
    val titleBrush = Brush.linearGradient(listOf(scheme.primary, scheme.tertiary))

    Box(
        modifier = modifier.background(backdrop),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .graphicsLayer {
                        val s = logoScale.value * (1f + 0.03f * pulse)
                        scaleX = s
                        scaleY = s
                        alpha = logoAlpha.value
                    },
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = center
                    val minDim = size.minDimension
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(scheme.primary.copy(alpha = 0.26f + 0.12f * pulse), Color.Transparent),
                            center = c,
                            radius = minDim * 0.66f,
                        ),
                        radius = minDim * 0.66f,
                        center = c,
                    )
                    rotate(degrees = sweep, pivot = c) {
                        drawCircle(
                            brush = Brush.sweepGradient(
                                colors = listOf(
                                    scheme.primary,
                                    scheme.tertiary,
                                    scheme.primary.copy(alpha = 0f),
                                    scheme.primary,
                                ),
                                center = c,
                            ),
                            radius = minDim * 0.46f,
                            center = c,
                            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round),
                        )
                    }
                    val discRadius = minDim * 0.36f
                    drawCircle(
                        brush = Brush.linearGradient(
                            colors = listOf(scheme.primary, scheme.tertiary),
                            start = Offset(c.x - discRadius, c.y - discRadius),
                            end = Offset(c.x + discRadius, c.y + discRadius),
                        ),
                        radius = discRadius,
                        center = c,
                    )
                    val triangle = Path().apply {
                        moveTo(c.x - discRadius * 0.22f, c.y - discRadius * 0.42f)
                        lineTo(c.x - discRadius * 0.22f, c.y + discRadius * 0.42f)
                        lineTo(c.x + discRadius * 0.46f, c.y)
                        close()
                    }
                    drawPath(triangle, scheme.onPrimary)
                    drawPath(
                        triangle,
                        scheme.onPrimary,
                        style = Stroke(width = 5.dp.toPx(), join = StrokeJoin.Round),
                    )
                }
            }

            Spacer(Modifier.height(28.dp))

            Text(
                text = "Rummy Music",
                modifier = Modifier.graphicsLayer {
                    alpha = nameAlpha.value
                    translationY = (1f - nameAlpha.value) * 20.dp.toPx()
                },
                style = TextStyle(
                    brush = titleBrush,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-0.3).sp,
                ),
            )

            Spacer(Modifier.height(10.dp))

            Text(
                text = "Menyiapkan musikmu...",
                modifier = Modifier.graphicsLayer {
                    alpha = tagAlpha.value
                    translationY = (1f - tagAlpha.value) * 12.dp.toPx()
                },
                style = TextStyle(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = 0.4.sp,
                    color = scheme.onSurface.copy(alpha = 0.55f),
                ),
            )
        }
    }
}
